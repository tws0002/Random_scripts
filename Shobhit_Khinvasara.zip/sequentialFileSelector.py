import sys
import os
import Tkinter
import tkFileDialog
import PySide.QtCore as qc
import PySide.QtGui as qg
fileRoot = 'sequenceFileSelector/'

class SequentialFileSelector():
    def __init__(self):
        self.app = qg.QApplication(sys.argv)
        self.filesList = []
        self.mainDialog = qg.QDialog()
        self.mainLayout = qg.QVBoxLayout()
        self.mainDialog.setLayout(self.mainLayout)
        self.mainDialog.setWindowTitle("Sequential File Selector")
        self.fileListWidget = qg.QListWidget()
        self.mainLayout.addWidget(self.fileListWidget)
        self.buttonLayout = qg.QHBoxLayout()
        self.chooseButton = qg.QPushButton("Choose Folder")
        self.buttonLayout.addWidget(self.chooseButton)
        self.chooseButton.clicked.connect(self.chooseFolder)
        self.printButton = qg.QPushButton("Print Files")
        self.buttonLayout.addWidget(self.printButton)
        self.printButton.clicked.connect(self.printFiles)
        self.cancelButton = qg.QPushButton("Cancel")
        self.cancelButton.clicked.connect(self.cancel)
        self.buttonLayout.addWidget(self.cancelButton)
        self.mainLayout.addLayout(self.buttonLayout)
        self.mainDialog.show()
        sys.exit(self.app.exec_())

    def populateList(self, fileList):
        self.fileListWidget.addItems(fileList)

    def chooseFolder(self):
        folderPath = "Q:\Office\Tests\\test_programming\sequenceFileSelector\\"
        filesList = [f for f in os.listdir(folderPath) if os.path.isfile(os.path.join(folderPath, f))]
        filesList.sort()
        for i in range(len(filesList) - 1):
            filePieces = filesList[i].rsplit(".")
            print len(filePieces)
            if len(filePieces) <= 2:
                self.filesList.append(filesList[i])

            else:
                try:
                    int(filePieces[1])
                    j = i
                    filePiece = filePieces[0]
                    print filePiece
                    while filePiece == filePieces[0]:
                        filePiece = filesList[j].rsplit(".")[0]
                        print j
                        if j > range(len(filesList) - 1):
                            return
                        j += 1
                    self.filesList.append(filePieces[0]+".%0"+str(j)+"."+filePieces[2] + " " + str(i) +"-"+str(j))
                    print i
                    i = j

                except ValueError:
                    self.filesList.append(filesList[i])

        self.populateList(self.filesList)


    def printFiles(self):
        pass

    def cancel(self):
        self.mainDialog.close()

tool = SequentialFileSelector()