import os

def parseInt(num):
	try:
		return int(num)
	except:
		return None

def collectFiles(root):
	files = os.listdir(root)
	files.sort()

	currentSequence = None
	sequence = None
	parsedFiles = []

	# loop through and collect single files and sequences
	for filename in files:
		parts = filename.split('.')
		# not a sequence
		if len(parts) < 3 or parseInt(parts[-2]) == None:
			parsedFiles.append(filename)
		# same as current sequence
		elif currentSequence == '.'.join(parts[0:-2]):
			parsedFiles[-1].append(parts)
		# new sequence
		else:
			parsedFiles.append([parts])
			currentSequence = '.'.join(parts[0:-2])

	# loop through again and collapse the sequences
	for i, filenames in enumerate(parsedFiles):
		# plain strings are fine
		if type(filenames) is not list:
			continue
		# collapse single files
		if len(filenames) == 1:
			parsedFiles[i] = '.'.join(filenames[0])
		else:
			startFrame = int(filenames[0][-2])
			endFrame = int(filenames[-1][-2])
			fileText = '.'.join(filenames[0][0:-2])
			fileText += '.%0' + str(len(filenames[0][-1]))
			fileText += 'd.' + filenames[0][-1]
			fileText += ' %d-%d' % (startFrame, endFrame)
			parsedFiles[i] = fileText

	return parsedFiles


if __name__ == '__main__':
	files = collectFiles('sequenceFileSelector/')
	print '\n'.join(files)
